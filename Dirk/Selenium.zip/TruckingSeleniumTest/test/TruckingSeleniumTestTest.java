/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;
import javax.swing.JOptionPane;
import org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TruckingSeleniumTestTest {
    public static WebDriver driver;
@Test
public void testTrucking() {
    //checks search and details
System.setProperty("webdriver.chrome.driver", "C:\\Users\\dstat\\Desktop\\chromedriver_win32\\chromedriver.exe");
driver = new ChromeDriver();

driver.get("https://indianatruckingchameleontracker.azurewebsites.net/");

WebElement trucking = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[3]/a"));
trucking.click();

WebElement search = driver.findElement(By.xpath("/html/body/div[1]/main/div/form/div[1]/div[1]/input"));
search.sendKeys("SCHAFSTALL");

WebElement searchbtn = driver.findElement(By.xpath("/html/body/div[1]/main/div/form/div[1]/div[2]/button"));
searchbtn.click();

WebElement result = driver.findElement(By.xpath("/html/body/div[1]/main/div/table/tbody/tr/td[2]"));
assertEquals(result.getText().contains("SCHAFSTALL INC"), true);
driver.close();
}
@Test
public void testLogin() {
    //tests login and see if admin controls are enabled (for trucking)
System.setProperty("webdriver.chrome.driver", "C:\\Users\\dstat\\Desktop\\chromedriver_win32\\chromedriver.exe");
driver = new ChromeDriver();

driver.get("https://indianatruckingchameleontracker.azurewebsites.net/");
WebElement loginbtn = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[2]/a"));
loginbtn.click();
WebElement email = driver.findElement(By.xpath("/html/body/div[1]/main/div/div[2]/section/form/div[2]/input"));
email.sendKeys("AdminUser@trucking.com");
WebElement password = driver.findElement(By.xpath("/html/body/div[1]/main/div/div[2]/section/form/div[3]/input"));
password.sendKeys("Password1234!");
WebElement signin = driver.findElement(By.xpath("/html/body/div[1]/main/div/div[2]/section/form/div[5]/button"));
signin.click();
WebElement usernamein = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[1]/li[1]/a"));
assertEquals(usernamein.getText().contains("AdminUser@trucking.com"), true);
//if log in was sucessfull
WebElement trucking = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[3]/a"));
trucking.click();
WebElement createnew = driver.findElement(By.xpath("/html/body/div/main/div/p/a"));
assertEquals(createnew.getText().contains("Create New"), true);
driver.close();
}
@Test
public void testMap() {
    //finds and selects map on SAKRATIE INC, then checks latitude and longitude
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\dstat\\Desktop\\chromedriver_win32\\chromedriver.exe");
    driver = new ChromeDriver();
    driver.get("https://indianatruckingchameleontracker.azurewebsites.net/");
    WebElement Chameleon = driver.findElement(By.xpath("/html/body/header/nav/div/div/ul[2]/li[2]/a"));
    Chameleon.click();

    WebElement Map = driver.findElement(By.xpath("/html/body/div[1]/main/div/table/tbody/tr[1]/td[5]/a[2]"));
    Map.click();
    WebElement CompanyLat = driver.findElement(By.id("lat"));
    WebElement CompanyLong = driver.findElement(By.id("long"));
    assertEquals(CompanyLat.getText(), "40.7516367");
    assertEquals(CompanyLong.getText(), "-86.3598428");
    driver.close();
}

    
    public TruckingSeleniumTestTest() {
    }

   
}

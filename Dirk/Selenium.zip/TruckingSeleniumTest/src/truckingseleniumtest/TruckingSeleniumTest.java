/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package truckingseleniumtest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
/**
 *
 * @author dstat
 */
public class TruckingSeleniumTest {
static WebDriver driver;
    /**
     * @param args the command line arguments
     */
 
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\dstat\\Desktop\\chromedriver_win32\\chromedriver.exe");
        System.out.println("Test initiated");
        driver = new ChromeDriver();
        driver.get("https://localhost:44339/");
        System.out.println("Page title is " + driver.getTitle());
        driver.quit();
    }
   
}

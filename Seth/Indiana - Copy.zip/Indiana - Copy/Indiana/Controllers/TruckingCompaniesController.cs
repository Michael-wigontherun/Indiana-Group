﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Indiana.Data;
using Indiana.Models;

namespace Indiana.Controllers
{
    public class TruckingCompaniesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TruckingCompaniesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: TruckingCompanies
        public async Task<IActionResult> Index()
        {
            return View(await _context.TruckingCompanies.ToListAsync());
        }

        // GET: TruckingCompanies/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var truckingCompanies = await _context.TruckingCompanies
                .FirstOrDefaultAsync(m => m.Usdot == id);
            if (truckingCompanies == null)
            {
                return NotFound();
            }

            return View(truckingCompanies);
        }

        // GET: TruckingCompanies/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TruckingCompanies/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Usdot,LegalName,Dbaname,CarrierOperation,HmFlag,PcFlag,PhyStreet,PhyCity,PhyState,PhyZip,PhyCountry,MailingStreet,MailingCity,MailingState,MailingZip,MailingCountry,Telephone,Fax,EmailAddress,Mcs150Date,Mcs150Mileage,Mcs150MileageYear,AddDate,OicState,NbrPowerUnit,DriverTotal,GeoLocation,AddminId")] TruckingCompanies truckingCompanies)
        {
            if (ModelState.IsValid)
            {
                _context.Add(truckingCompanies);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(truckingCompanies);
        }

        // GET: TruckingCompanies/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var truckingCompanies = await _context.TruckingCompanies.FindAsync(id);
            if (truckingCompanies == null)
            {
                return NotFound();
            }
            return View(truckingCompanies);
        }

        // POST: TruckingCompanies/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Usdot,LegalName,Dbaname,CarrierOperation,HmFlag,PcFlag,PhyStreet,PhyCity,PhyState,PhyZip,PhyCountry,MailingStreet,MailingCity,MailingState,MailingZip,MailingCountry,Telephone,Fax,EmailAddress,Mcs150Date,Mcs150Mileage,Mcs150MileageYear,AddDate,OicState,NbrPowerUnit,DriverTotal,GeoLocation,AddminId")] TruckingCompanies truckingCompanies)
        {
            if (id != truckingCompanies.Usdot)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(truckingCompanies);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TruckingCompaniesExists(truckingCompanies.Usdot))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(truckingCompanies);
        }

        // GET: TruckingCompanies/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var truckingCompanies = await _context.TruckingCompanies
                .FirstOrDefaultAsync(m => m.Usdot == id);
            if (truckingCompanies == null)
            {
                return NotFound();
            }

            return View(truckingCompanies);
        }

        // POST: TruckingCompanies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var truckingCompanies = await _context.TruckingCompanies.FindAsync(id);
            _context.TruckingCompanies.Remove(truckingCompanies);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TruckingCompaniesExists(string id)
        {
            return _context.TruckingCompanies.Any(e => e.Usdot == id);
        }
    }
}
